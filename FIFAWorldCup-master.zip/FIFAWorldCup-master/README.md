# FIFA World Cup

- [Script](http://nbviewer.ipython.org/github/pratapvardhan/FIFAWorldCup/blob/master/fifa-wc-squads.ipynb?create=1) to scrape every world cup's qualified team's squad data from [Wikipedia](http://en.wikipedia.org/)

# Data

- FIFA world cup squads (1930-2014) data from Wikipedia
